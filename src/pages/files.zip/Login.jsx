import React, { useState } from "react";
import { useApp } from "../context/AppContext.jsx";
import Icon from "../components/Icon.jsx";

export default function Login() {
  const { navigate, pushToast, setUser } = useApp();

  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw]     = useState(false);
  const [remember, setRemember] = useState(false);
  const [errors, setErrors]     = useState({});

  const validate = () => {
    const e = {};
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) e.email = "Please enter a valid email.";
    if (password.length < 6) e.password = "Password must be at least 6 characters.";
    return e;
  };

  const handleLogin = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});

    const users = JSON.parse(localStorage.getItem("uxnin_users") || "[]");
    const user  = users.find((u) => u.email === email.trim() && u.password === password);

    if (!user) {
      setErrors({ email: "Email or password is incorrect." });
      return;
    }

    setUser(user);
    pushToast("Welcome back, " + user.name.split(" ")[0] + "!");
    navigate("home");
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-brand">UXNIN</div>
          <h1>Welcome back</h1>
          <p>Sign in to your account to continue</p>
        </div>

        {/* Email */}
        <div className="auth-field">
          <label>Email address</label>
          <div className={"auth-input-wrap" + (errors.email ? " has-error" : "")}>
            <Icon name="mail" size={17}/>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              autoComplete="email"
            />
          </div>
          {errors.email && <div className="auth-error">{errors.email}</div>}
        </div>

        {/* Password */}
        <div className="auth-field">
          <label>Password</label>
          <div className={"auth-input-wrap" + (errors.password ? " has-error" : "")}>
            <Icon name="lock" size={17}/>
            <input
              type={showPw ? "text" : "password"}
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              autoComplete="current-password"
            />
            <button className="auth-eye" type="button" onClick={() => setShowPw(!showPw)}>
              <Icon name={showPw ? "eyeOff" : "eye"} size={17}/>
            </button>
          </div>
          {errors.password && <div className="auth-error">{errors.password}</div>}
        </div>

        {/* Options */}
        <div className="auth-options">
          <label className="auth-check">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)}/>
            <span className="auth-check-box"/>
            Remember me
          </label>
          <a href="#" className="auth-link">Forgot password?</a>
        </div>

        <button className="btn btn-teal btn-block" onClick={handleLogin}>
          Sign in <Icon name="chevron" size={15}/>
        </button>

        <div className="auth-divider"><span>or continue with</span></div>

        <div className="auth-social">
          <button className="btn auth-social-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Google
          </button>
          <button className="btn auth-social-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="#1877F2">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            Facebook
          </button>
        </div>

        <div className="auth-footer">
          Don't have an account?{" "}
          <button className="auth-link-btn" onClick={() => navigate("register")}>
            Create one
          </button>
        </div>
      </div>
    </div>
  );
}
