import React, { useState } from "react";
import { useApp } from "../context/AppContext.jsx";
import Icon from "../components/Icon.jsx";

const STRENGTHS = [
  { label: "Weak",   color: "var(--coral)" },
  { label: "Fair",   color: "var(--amber)" },
  { label: "Good",   color: "var(--sky)"   },
  { label: "Strong", color: "var(--teal)"  },
];

function getStrength(pw) {
  let s = 0;
  if (pw.length >= 6)  s++;
  if (pw.length >= 10) s++;
  if (/[A-Z]/.test(pw) && /[0-9]/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

export default function Register() {
  const { navigate, pushToast, setUser } = useApp();

  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", password: "", confirm: "" });
  const [showPw, setShowPw]   = useState(false);
  const [agreed, setAgreed]   = useState(false);
  const [errors, setErrors]   = useState({});

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const strength = form.password ? getStrength(form.password) : 0;

  const validate = () => {
    const e = {};
    if (!form.firstName.trim())                              e.firstName = "Required.";
    if (!form.lastName.trim())                               e.lastName  = "Required.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) e.email  = "Please enter a valid email.";
    if (form.password.length < 6)                            e.password  = "Min. 6 characters.";
    if (form.confirm !== form.password)                      e.confirm   = "Passwords do not match.";
    if (!agreed)                                             e.terms     = "You must agree to continue.";
    return e;
  };

  const handleRegister = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});

    const users = JSON.parse(localStorage.getItem("uxnin_users") || "[]");
    if (users.find((u) => u.email === form.email.trim())) {
      setErrors({ email: "This email is already registered." });
      return;
    }

    const newUser = {
      name: form.firstName.trim() + " " + form.lastName.trim(),
      email: form.email.trim(),
      password: form.password,
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    localStorage.setItem("uxnin_users", JSON.stringify(users));

    setUser(newUser);
    pushToast("Welcome, " + newUser.name.split(" ")[0] + "!");
    navigate("home");
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-header">
          <div className="auth-brand">UXNIN</div>
          <h1>Create your account</h1>
          <p>Join thousands of serious lifters</p>
        </div>

        {/* Name row */}
        <div className="auth-row">
          <div className="auth-field">
            <label>First name</label>
            <div className={"auth-input-wrap" + (errors.firstName ? " has-error" : "")}>
              <Icon name="user" size={17}/>
              <input
                type="text"
                placeholder="Ahmed"
                value={form.firstName}
                onChange={set("firstName")}
              />
            </div>
            {errors.firstName && <div className="auth-error">{errors.firstName}</div>}
          </div>
          <div className="auth-field">
            <label>Last name</label>
            <div className={"auth-input-wrap" + (errors.lastName ? " has-error" : "")}>
              <Icon name="user" size={17}/>
              <input
                type="text"
                placeholder="Ali"
                value={form.lastName}
                onChange={set("lastName")}
              />
            </div>
            {errors.lastName && <div className="auth-error">{errors.lastName}</div>}
          </div>
        </div>

        {/* Email */}
        <div className="auth-field">
          <label>Email address</label>
          <div className={"auth-input-wrap" + (errors.email ? " has-error" : "")}>
            <Icon name="mail" size={17}/>
            <input
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={set("email")}
              autoComplete="email"
            />
          </div>
          {errors.email && <div className="auth-error">{errors.email}</div>}
        </div>

        {/* Password */}
        <div className="auth-field">
          <label>Password</label>
          <div className={"auth-input-wrap" + (errors.password ? " has-error" : "")}>
            <Icon name="lock" size={17}/>
            <input
              type={showPw ? "text" : "password"}
              placeholder="Min. 6 characters"
              value={form.password}
              onChange={set("password")}
              autoComplete="new-password"
            />
            <button className="auth-eye" type="button" onClick={() => setShowPw(!showPw)}>
              <Icon name={showPw ? "eyeOff" : "eye"} size={17}/>
            </button>
          </div>
          {form.password && (
            <div className="auth-strength">
              <div className="strength-bars">
                {[0,1,2,3].map((i) => (
                  <span
                    key={i}
                    style={{ background: i < strength ? STRENGTHS[strength - 1].color : "var(--border)" }}
                  />
                ))}
              </div>
              <span className="strength-lbl" style={{ color: STRENGTHS[strength - 1]?.color }}>
                {STRENGTHS[strength - 1]?.label}
              </span>
            </div>
          )}
          {errors.password && <div className="auth-error">{errors.password}</div>}
        </div>

        {/* Confirm */}
        <div className="auth-field">
          <label>Confirm password</label>
          <div className={"auth-input-wrap" + (errors.confirm ? " has-error" : "")}>
            <Icon name="lock" size={17}/>
            <input
              type="password"
              placeholder="Repeat your password"
              value={form.confirm}
              onChange={set("confirm")}
              autoComplete="new-password"
              onKeyDown={(e) => e.key === "Enter" && handleRegister()}
            />
          </div>
          {errors.confirm && <div className="auth-error">{errors.confirm}</div>}
        </div>

        {/* Terms */}
        <div className="auth-terms">
          <label className="auth-check">
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)}/>
            <span className="auth-check-box"/>
            I agree to the <a href="#" className="auth-link">Terms of Service</a> and{" "}
            <a href="#" className="auth-link">Privacy Policy</a>
          </label>
          {errors.terms && <div className="auth-error">{errors.terms}</div>}
        </div>

        <button className="btn btn-teal btn-block" onClick={handleRegister}>
          Create account <Icon name="chevron" size={15}/>
        </button>

        <div className="auth-divider"><span>or sign up with</span></div>

        <div className="auth-social">
          <button className="btn auth-social-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Google
          </button>
          <button className="btn auth-social-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="#1877F2">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            Facebook
          </button>
        </div>

        <div className="auth-footer">
          Already have an account?{" "}
          <button className="auth-link-btn" onClick={() => navigate("login")}>
            Sign in
          </button>
        </div>
      </div>
    </div>
  );
}
